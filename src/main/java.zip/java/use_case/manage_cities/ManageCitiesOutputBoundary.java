package use_case.manage_cities;

public interface ManageCitiesOutputBoundary {
}
