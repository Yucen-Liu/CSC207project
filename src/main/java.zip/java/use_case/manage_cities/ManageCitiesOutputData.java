package use_case.manage_cities;

public class ManageCitiesOutputData {
}
