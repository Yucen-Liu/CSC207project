package interface_adapter.manage_cities;

public class ManageCitiesPresenter {
}
