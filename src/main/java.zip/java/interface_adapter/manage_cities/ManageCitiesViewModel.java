package interface_adapter.manage_cities;

public class ManageCitiesViewModel {
    public String getViewName() {
        return null;
    }
}
